# Frontend TODO

Remaining items from the project audit (2026-10-08). Items 1–4 of that audit are done:
Wear OS dependency removed, deprecations fixed, duplicate components deleted,
touch targets raised to 48dp.

---

## 1. Enable R8 for release builds

`app/build.gradle.kts` currently disables optimization entirely:

```kotlin
buildTypes {
    release {
        optimization { enable = false }
    }
}
```

No shrinking, no obfuscation, no resource stripping. Fine while marking, wrong before
any real distribution.

- [x] Turn optimization back on for `release`
- [x] Enable resource shrinking (depends on code shrinking being on)
- [x] Add a `proguard-rules.pro` — check whether the kotlinx.serialization
      serializers for `Screen` survive; `@Serializable` classes usually need a keep rule
- [~] Build a release APK and walk the whole flow, specifically navigation
      (serializer stripping shows up as a runtime crash, not a build failure)
      Done on an emulator up to Register step 4 and the sign-in face check. Home and the
      vote flow need a real face scan to reach, so check those on a phone.
      Found and fixed: ML Kit face detector was null under R8 (keep rules added).

**Do this before item 2** — resource shrinking is what makes the unused assets a
non-issue automatically.

## 2. Prune unused assets

Lint reports 14 unused resources.

- [x] `drawable-nodpi/` holds 18 party logos; `SampleParties` references 5
      (`anc`, `da`, `eff`, `ifp`, `actionsa`). Either finish the party list or delete
      the other 13
- [x] `drawable/success_check.jpg` is referenced nowhere — delete
- [x] `IconLocation` warning: a bitmap sitting in density-independent `drawable/`
      (same file, so deleting it clears this too)
- [x] `IconXmlAndPng` warning: `ic_launcher` exists as both `.xml` and `.webp`
      in `mipmap-xxxhdpi` — pick one

## 3. Extract hardcoded strings

`res/values/strings.xml` has 2 entries; every other piece of UI copy is inline in
Kotlin.

- [x] Move user-facing text to `strings.xml` (Manifestos and Results screens still pending, in progress on their own branches)
- [x] Language pill now opens a real picker: English, Afrikaans, isiZulu, isiXhosa (KAN-38).
      Translations are first drafts and need a native-speaker review before release.
- [x] Add `tools:locale` and check RTL layout — `supportsRtl="true"` is already
      set in the manifest, so it is claimed but untested
      Checked (KAN-39): RtlLayoutTest, plus a manual run on an emulator with an RTL locale.
      tools:locale ships with the translations PR (KAN-38).

## 4. Replace the test stubs

`app/src/test` and `app/src/androidTest` contain only generated examples.

- [x] Unit tests: `RegistrationViewModel` state transitions, `sampleLookup`
      receipt matching
- [x] UI tests worth having: registration back navigation, the three `HeroState`
      renders on home, party selection → review passing the right party

## 5. Build a real Settings screen

`Screen.Settings` renders `InfoScreen` as a placeholder, but the bottom bar
advertises it as its own destination.

- [x] Decide what belongs there (language, notifications, sign out, about)
- [x] Implemented SettingsScreen with Account, Language, Notifications, Theme, Biometrics, Privacy and Log Out options

## 6. Dependency updates (low priority)

Lint flags these; none are urgent and each risks churn.

- [x] `coreKtx` 1.10.1 → 1.19.1 (also declared directly now; CameraView uses it)
- [x] Gradle wrapper 9.8.0 → 9.8.1; Kotlin 2.4.21, splashscreen 1.2.0,
      kotlinx-serialization 1.11.0, CameraX 1.6.2. AGP 9.4.1 is already current
- [x] Checked: unit tests, lint (no dependency warnings left) and the face-check
      camera screen on the emulator

---

## Smaller things noticed

- [x] `ui/Components/` renamed to lowercase `ui/components/` to match every other package (KAN-45)
- [x] `AppFontFamily` in `ui/theme/Type.kt` was `FontFamily.SansSerif` (now Inter, KAN-46). Dropping a
      `.ttf` into `res/font/` and changing that one line moves the whole app onto
      a brand typeface
- [ ] `Screen.Review` is a `data object`, with the selected party held in graph
      state. A `data class Review(val partyId: String)` would survive process
      death — see the Obsidian note "Jetpack Compose Navigation - NavHost Recipe"
